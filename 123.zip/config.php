<?php
$host = 'localhost';
$dbname = 'rayjuni_eu_org';
$user = 'rayjuni_eu_org';
$pass = '2QFjRTAmmK9s9J56';
$conn = new mysqli($host, $user, $pass, $dbname);
$conn->set_charset("utf8mb4");
if ($conn->connect_error) die("数据库连接失败: " . $conn->connect_error);
?>